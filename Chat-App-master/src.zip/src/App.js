import React from 'react';
import Navigation from './Navigation';

class App extends React.PureComponent {
     render() {
         return (<Navigation />);
     }
}
                 
                 
                 
export default App;